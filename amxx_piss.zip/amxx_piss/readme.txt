Plugin: Amxx Piss
Version: 2.0
Author: KRoTaL (Based on TakeADookie by PaintLancer)


1.0  Release
1.1  Better effect
1.2  Bug fix
1.3  New effect + piss puddle
1.4a New effects, only for cs/cz/dod
1.4b New effects, only for other mods than cs/cz/dod
1.5  #define NO_CS_CZ added
1.6  Bug fix (DoD)
1.7  Bug fix
1.8  Some checks added
1.9  #define NO_CS_CZ changed into #define NO_CS_CZ
2.0  New cvar : amx_piss_effect

Commands: 

	To piss on a dead body you have to bind a key to: piss
	Open your console and write: bind "key" "piss"
	ex: bind "x" "piss"
	Then stand still above a dead player (cs/cz only), press your key and you'll piss on them ! 
	You can control the direction of the stream with your mouse.
	You are not able to move or to shoot for 10 seconds when you piss, so beware (cs/cz only).
	The puddle of piss will appear where you are aiming at 2 seconds after you start pissing, 
	so try to aim at the dead body instead of the sky or a wall ;)

	Players can say "/piss" in the chat to get some help.

Cvars:

	amx_maxpees 6		-	Maximum number of times a player is allowed to piss per round.

	amx_piss_admin 0	-	0 : All the players are allowed to piss
				        1 : Only admins with ADMIN_LEVEL_A flag are allowed to piss

	amx_piss_effect 0	-	0 : yellow bloodsprite
				        1 : yellow laserbeam

Setup:

	You need to put these files on your server:

	sound/piss/pissing.wav
	models/piss/piss_puddle1.mdl  
	models/piss/piss_puddle2.mdl	
	models/piss/piss_puddle3.mdl  	 
	models/piss/piss_puddle4.mdl  	
	models/piss/piss_puddle5.mdl 	
	models/piss/piss.mdl

	You need to enable Fun and Engine Modules for cs/cs-cz.
	You need to enable Engine Module for the other mods.


	Use amxx_piss_cs_cz.amxx if you use CS or CS-CZ.
	Use amxx_piss.amxx if you use another mod (dod, tfc, ...).
	(Compiled with amxmodx 1.0)


Credits:

	Rastin for his trousers fly sounds
	SLayer KL for his piss puddle models



If you want to compile with another version of amxx,
open amxx_piss.sma file (addons/amxx/scripting) and modify this line according to the mod you use :

// UNCOMMENT IF YOU USE ANOTHER MOD THAN CS and CS-CZ
//#define NO_CS_CZ

"Uncomment" means deleting the "//"